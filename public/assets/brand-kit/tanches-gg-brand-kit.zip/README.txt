TANCHES.GG brand kit

SVG: vector, scales to any size (print, signage, apparel).
PNG: transparent background, high resolution (screen, slides, social).

The lion mark always sits on its rounded square plate.

lockup-color-light  Full-color lockup for white / pale backgrounds
lockup-color-dark   Full-color lockup for near-black backgrounds
lockup-black/white  One-ink lockups (lion knocked out of the plate)
icon-color          Lion mark on its plate, any background
icon-black/white    One-ink icons
wordmark-*          [TANCHES.GG] type only

Clear space: half the icon height on all sides. Minimum width: 120px on screen, 1 inch in print.
Colors: Flame #F53F1D, Rose #E23869, Magenta #DA358B, Violet #C92FD1, Base #08080A.
Type: Sora (display + UI), JetBrains Mono (labels + data). Both free on Google Fonts.

Questions: contact@tanches.gg
